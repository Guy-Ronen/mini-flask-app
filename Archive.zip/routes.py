# from flask import Flask, render_template, request, flash, redirect, url_for
# from flask_wtf import FlaskForm
# from flask_login import login_required, login_user, logout_user
# from wtforms import StringField, SubmitField
# from wtforms.fields.simple import PasswordField
# from wtforms.validators import DataRequired, EqualTo, Email
# from models import User
# from app import db, login_manager

# class RegisterForm(FlaskForm):
#     email = StringField('Email', validators=[DataRequired()])
#     password = PasswordField('Password', validators=[DataRequired()])
#     password2 =PasswordField('Repeat Password', validators=[DataRequired(), EqualTo('password')])
#     submit =SubmitField('Register')

# class LoginForm(FlaskForm):
#     email = StringField('Email', validators=[DataRequired()])
#     password = PasswordField('Password', validators=[DataRequired()])
#     submit =SubmitField('Login')


# @app.route('/')
# def index():
#     guy = User.query.all()
#     print(guy)
#     return render_template('index.html')

# @app.route('/login',methods=['GET','POST'])
# def login():
#     form = LoginForm()
#     if form.validate_on_submit():
#         user = User.query.filter_by(email = form.email.data).first()
#         if user and form.password.data == user.password:
#             return redirect(url_for('sucsess'))
#         else:
#             return render_template('login.html',form =form)
#     return render_template('login.html', form = form)


# @app.route('/register',methods=['GET','POST'])
# def register():
#     form = RegisterForm()
#     if form.validate_on_submit():
#         user = User(email = form.email.data, password=form.password.data)
#         db.session.add(user)
#         db.session.commit()
#         return redirect(url_for('login'))
#     return render_template('register.html', form = form)


# @app.route('/sucsess')
# def sucsess():
#     return render_template('sucsess.html')



from flask import Flask, render_template, request, flash, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.fields.simple import PasswordField
from wtforms.validators import DataRequired, EqualTo, Email
from models import User
from app import app, db

class LoginForm(FlaskForm):
    email = StringField(label = 'Email', validators = [DataRequired()])
    password = PasswordField(label = 'Password', validators = [DataRequired()])
    submit = SubmitField(label = 'Login')

class RegisterForm(FlaskForm):
    email = StringField(label = 'Email', validators = [DataRequired()])
    password = PasswordField(label = 'Password', validators = [DataRequired()])
    password2 = PasswordField(label = 'Repeat Password', validators = [DataRequired(), EqualTo('password')])
    submit = SubmitField(label = 'Register')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods = ['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email = form.email.data).first()
        print(user)
        if user and (user.password == form.password.data):
            print('world')
            return redirect(url_for('sucsess'))
    return render_template('login.html', form = form)

@app.route('/register', methods = ['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(email = form.email.data, password = form.password.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('register.html', form = form)

@app.route('/sucsess')
def sucsess():
    return render_template('sucsess.html')