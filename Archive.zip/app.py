# from flask import Flask, render_template,request,url_for,redirect
# from flask_sqlalchemy import SQLAlchemy

# from flask_wtf import FlaskForm
# from wtforms import StringField, SubmitField, PasswordField
# from wtforms.validators import DataRequired, EqualTo
# from models import User

# from flask import Flask
# from flask_login import LoginManager
# from flask_sqlalchemy import SQLAlchemy


# app = Flask(__name__)

# app.config['SECRET_KEY'] = 'secretkey'
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
# app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# db = SQLAlchemy(app)
# import routes
################################################



from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'randomstuff'

db = SQLAlchemy(app)

import routes









